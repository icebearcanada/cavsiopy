attitude_analysis: Module to obtain instrument pointing direction in various reference frames
=============================================================================================
.. automodule:: attitude_analysis
   :members:
