use_rotation_matrices: Module to rotate instrument and transform between reference frames
=========================================================================================
.. automodule:: use_rotation_matrices
   :members:   
