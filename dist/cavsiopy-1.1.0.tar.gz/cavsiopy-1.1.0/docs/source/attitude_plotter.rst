attitude_plotter: Module to visualize satellite instrument pointing direction
=============================================================================
.. automodule:: attitude_plotter
   :members:
